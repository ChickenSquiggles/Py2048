import os
import random
try:
    import pygame
except ImportError:
    os.system('pip install pygame --pre')
    print('Please restart the program.')
    os.system('pause')
    exit(0)
pygame.init()
os.system('CLS')
BACK = (164,147,129)
size = (530, 530)
screen = pygame.display.set_mode(size)
pygame.display.set_caption('2048 In Python')
carryOn = True
asset = __file__
for i in range (len(asset)):
    if asset[i] == '\\':
        asset = asset.replace(asset[i], '/')
asset = asset.strip('2048.py')
asset += 'Assets/'
# Load Images
class blocks:
    #etc
    blockblank = pygame.image.load(f'{asset}BlankTile.png')
    blockerror = pygame.image.load(f'{asset}ErrorTile.png')
    #main
    block2 = pygame.image.load(f'{asset}2Tile.png')
    block4 = pygame.image.load(f'{asset}4Tile.png')
    block8 = pygame.image.load(f'{asset}8Tile.png')
    block16 = pygame.image.load(f'{asset}16Tile.png')
    block32 = pygame.image.load(f'{asset}32Tile.png')
    block64 = pygame.image.load(f'{asset}64Tile.png')
    block128 = pygame.image.load(f'{asset}128Tile.png')
    block256 = pygame.image.load(f'{asset}256Tile.png')
    block512 = pygame.image.load(f'{asset}512Tile.png')
    block1024 = pygame.image.load(f'{asset}1024Tile.png')
    block2048 = pygame.image.load(f'{asset}2048Tile.png')
    #popped
    block4p = pygame.image.load(f'{asset}4TilePop.png')
    block8p = pygame.image.load(f'{asset}8TilePop.png')
    block16p = pygame.image.load(f'{asset}16TilePop.png')
    block32p = pygame.image.load(f'{asset}32TilePop.png')
    block64p = pygame.image.load(f'{asset}64TilePop.png')
    block128p = pygame.image.load(f'{asset}128TilePop.png')
    block256p = pygame.image.load(f'{asset}256TilePop.png')
    block512p = pygame.image.load(f'{asset}512TilePop.png')
    block1024p = pygame.image.load(f'{asset}1024TilePop.png')
    block2048p = pygame.image.load(f'{asset}2048TilePop.png')
clock = pygame.time.Clock()

class hndl:
    vls = [
         [2,2,0,0] 
        ,[0,0,0,0]
        ,[0,0,0,0]
        ,[0,0,0,0]
    ]
    isnew = [
         [0,0,0,0] 
        ,[0,0,0,0]
        ,[0,0,0,0]
        ,[0,0,0,0]
    ]

    def newtile():
        while True:
            x = random.randint(0, 3)
            y = random.randint(0, 3)
            if (hndl.vls[x][y] == 0):
                n = random.randint(2,4)
                match n:
                    case 2:
                        hndl.vls[x][y] = 2
                    case 3:
                        hndl.vls[x][y] = 2
                    case 4:
                        hndl.vls[x][y] = 4
                break
    def first2():
        pass

    def movdown():
        oldi, oldj = 0, 0
        oldval = 0
        did = False
        for j in range(0, 4):
            shift = 0
            for i in range(3, -1, -1):
                if hndl.vls[i][j] == 0:
                    shift += 1
                else:
                    if i - 1 >= 0 and hndl.vls[i - 1][j] == hndl.vls[i][j]:
                        hndl.vls[i][j] *= 2
                        hndl.vls[i - 1][j] = 0
                        hndl.isnew[i][j] = 1
                        oldi, oldj = i-1, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    elif i - 2 >= 0 and hndl.vls[i - 1][j] == 0 and hndl.vls[i - 2][j] == hndl.vls[i][j]:
                        hndl.vls[i][j] *= 2
                        hndl.vls[i - 2][j] = 0
                        hndl.isnew[i][j] = 1
                        oldi, oldj = i-2, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    elif i == 3 and hndl.vls[2][j] + hndl.vls[1][j] == 0 and hndl.vls[0][j] == hndl.vls[3][
                        j]:
                        hndl.vls[3][j] *= 2
                        hndl.vls[0][j] = 0
                        hndl.isnew[3][j] = 1
                        oldi, oldj = 0, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    if shift > 0:
                        hndl.vls[i + shift][j] = hndl.vls[i][j]
                        hndl.vls[i][j] = 0
                        hndl.isnew[i+shift][j] = 1
                        oldi, oldj = i, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                if hndl.vls[i][j] == oldval:
                    hndl.isnew[i][j] = 0
        if did:
            hndl.newtile()
    def movright():
        did = False
        oldi, oldj = 0, 0
        oldval = 0
        for i in range(0, 4):
            shift = 0
            for j in range(3, -1, -1):
                if hndl.vls[i][j] == 0:
                    shift += 1
                else:
                    if j - 1 >= 0 and hndl.vls[i][j - 1] == hndl.vls[i][j]:
                        hndl.vls[i][j] *= 2
                        hndl.vls[i][j - 1] = 0
                        hndl.isnew[i][j] = 1
                        oldi, oldj = i, j-1
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    elif j - 2 >= 0 and hndl.vls[i][j - 1] == 0 and hndl.vls[i][j - 2] == hndl.vls[i][j]:
                        hndl.vls[i][j] *= 2
                        hndl.vls[i][j - 2] = 0
                        hndl.isnew[i][j] = 1
                        oldi, oldj = i, j-2
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    elif j == 3 and hndl.vls[i][2] + hndl.vls[i][1] == 0 and hndl.vls[0][j] == hndl.vls[3][
                        j]:
                        hndl.vls[i][3] *= 2
                        hndl.vls[i][0] = 0
                        hndl.isnew[i][3] = 1
                        oldi, oldj = i, 0
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    if shift > 0:
                        hndl.vls[i][j + shift] = hndl.vls[i][j]
                        hndl.vls[i][j] = 0
                        hndl.isnew[i][j+shift] = 1
                        oldi, oldj = i, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                if hndl.vls[i][j] == oldval:
                    hndl.isnew[i][j] = 0
        if did:
            hndl.newtile()
    def movleft():
        did = False
        oldi, oldj = 0, 0
        oldval = 0
        for i in range(0, 4):
            shift = 0
            for j in range(0, 4):
                if hndl.vls[i][j] == 0:
                    shift += 1
                else:
                    if j + 1 < 4 and hndl.vls[i][j + 1] == hndl.vls[i][j]:
                        hndl.vls[i][j] *= 2
                        hndl.vls[i][j + 1] = 0
                        hndl.isnew[i][j] = 1
                        oldi, oldj = i, j+1
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    elif j + 2 < 4 and hndl.vls[i][j + 1] == 0 and hndl.vls[i][j + 2] == hndl.vls[i][j]:
                        hndl.vls[i][j] *= 2
                        hndl.vls[i][j + 2] = 0
                        hndl.isnew[i][j] = 1
                        oldi, oldj = i, j+2
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    elif j == 0 and hndl.vls[i][1] + hndl.vls[i][2] == 0 and hndl.vls[i][3] == hndl.vls[i][
                        0]:
                        hndl.vls[i][0] *= 2
                        hndl.vls[i][3] = 0
                        hndl.isnew[i][0] = 1
                        oldi, oldj = i, 3
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    if shift > 0:
                        hndl.vls[i][j - shift] = hndl.vls[i][j]
                        hndl.vls[i][j] = 0
                        hndl.isnew[i][j-shift] = 1
                        oldi, oldj = i, j-shift
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                if hndl.vls[i][j] == oldval:
                    hndl.isnew[i][j] = 0
        if did:
            hndl.newtile()
    def movup():
        did = False
        oldi, oldj = 0, 0
        oldval = 0
        for j in range(0, 4):
            shift = 0
            for i in range(0, 4):
                if hndl.vls[i][j] == 0:
                    shift += 1
                else:
                    if i + 1 < 4 and hndl.vls[i + 1][j] == hndl.vls[i][j]:
                        hndl.vls[i][j] *= 2
                        hndl.vls[i + 1][j] = 0
                        hndl.isnew[i][j] = 1
                        oldi, oldj = i+1, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    elif i + 2 < 4 and hndl.vls[i + 1][j] == 0 and hndl.vls[i + 2][j] == hndl.vls[i][j]:
                        hndl.vls[i][j] *= 2
                        hndl.vls[i + 2][j] = 0
                        hndl.isnew[i][j] = 1
                        oldi, oldj = i+2, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    elif i == 0 and hndl.vls[1][j] + hndl.vls[2][j] == 0 and hndl.vls[3][j] == hndl.vls[0][
                        j]:
                        hndl.vls[0][j] *= 2
                        hndl.vls[3][j] = 0
                        hndl.isnew[0][j] = 1
                        oldi, oldj = 3, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                    if shift > 0:
                        hndl.vls[i - shift][j] = hndl.vls[i][j]
                        hndl.vls[i][j] = 0
                        hndl.isnew[i-shift][j] = 1
                        oldi, oldj = i-shift, j
                        oldval = hndl.vls[oldi][oldj]
                        did = True
                if hndl.vls[i][j] == oldval:
                    hndl.isnew[i][j] = 0
        if did:
            hndl.newtile()
pp = 0
#mainloop
while carryOn:
    for event in pygame.event.get():
        match event.type:
            #quit
            case pygame.QUIT:
                carryOn = False
            #keys
            case pygame.KEYDOWN:
                match event.key:
                    case pygame.K_w:
                        hndl.movup()
                    case pygame.K_d:
                        hndl.movright()
                    case pygame.K_s:
                        hndl.movdown()
                    case pygame.K_a:
                        hndl.movleft()
    screen.fill(BACK)
    #rendertile*
    for x in range (4):
        for y in range(4):
            match hndl.vls[y][x]:
                case 2:
                    screen.blit(blocks.block2,    (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 4:
                    screen.blit(blocks.block4,    (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 8:
                    screen.blit(blocks.block8,    (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 16:
                    screen.blit(blocks.block16,   (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 32:
                    screen.blit(blocks.block32,   (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 64:
                    screen.blit(blocks.block64,   (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 128:
                    screen.blit(blocks.block128,  (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 256:
                    screen.blit(blocks.block256,  (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 512:
                    screen.blit(blocks.block512,  (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 1024:
                    screen.blit(blocks.block1024, (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 2048:
                    screen.blit(blocks.block2048, (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case 0:
                    screen.blit(blocks.blockblank, (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
                case _:
                    screen.blit(blocks.blockerror, (   ((x*120) + (10*x))+10   ,   ((y*120) + (10*y))+10   ))
    #*rendertile
    #renderpop*
    for x in range(4):
        for y in range(4):
            if hndl.isnew[y][x]:
                match hndl.vls[y][x]:
                    case 4:
                        screen.blit(blocks.block4p,    (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 8:
                        screen.blit(blocks.block8p,    (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 16:
                        screen.blit(blocks.block16p,   (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 32:
                        screen.blit(blocks.block32p,   (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 64:
                        screen.blit(blocks.block64p,   (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 128:
                        screen.blit(blocks.block128p,  (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 256:
                        screen.blit(blocks.block256p,  (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 512:
                        screen.blit(blocks.block512p,  (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 1024:
                        screen.blit(blocks.block1024p, (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
                    case 2048:
                        screen.blit(blocks.block2048p, (   ((x*120) + (10*x))+7.5   ,   ((y*120) + (10*y))+7.5   ))
            pass
    pp += 1
    if (pp == 10):
        hndl.isnew = [
             [0,0,0,0] 
            ,[0,0,0,0]
            ,[0,0,0,0]
            ,[0,0,0,0]
        ]
        pp = 0
    #*renderpop
    pygame.display.flip()
    clock.tick(60)
pygame.quit()